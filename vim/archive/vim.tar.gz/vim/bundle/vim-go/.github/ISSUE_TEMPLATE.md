### Actual behavior

Write here what's happening ...

### Expected behavior

Write here what you're expecting ...

### Steps to reproduce:

Please create a reproducible case of your problem. Re produce it 
with a minimal `vimrc` with all plugins disabled and only `vim-go`
enabled:

1.
2.
3.

### Configuration

Add here your current configuration and additional information that might be
useful, such as:

* `vimrc` you used to reproduce
* vim version:
* vim-go version
* go version

